import React from 'react';

const Error404 = () => {
  return (
    <div>
        <h1>Error404</h1>
    </div>
  )
}

export default Error404;